package com.example.myapplication;


import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class phuc1 extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.phuc_b1);

        EditText editTextFahrenheit = findViewById(R.id.editTextFahrenheit);
        EditText editTextCelsius = findViewById(R.id.editTextCelsius);
        Button btnConvertToCelsius = findViewById(R.id.btnConvertToCelsius);
        Button btnConvertToFahrenheit = findViewById(R.id.btnConvertToFahrenheit);
        Button btnClear = findViewById(R.id.btnClear);

        btnConvertToCelsius.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String fahrenheitInput = editTextFahrenheit.getText().toString();
                if (!fahrenheitInput.isEmpty()) {
                    double fahrenheit = Double.parseDouble(fahrenheitInput);
                    double celsius = (fahrenheit - 32) * 5 / 9;
                    editTextCelsius.setText(String.format("%.2f", celsius));
                } else {
                    Toast.makeText(phuc1.this, "Please enter Fahrenheit value", Toast.LENGTH_SHORT).show();
                }
            }
        });

        btnConvertToFahrenheit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String celsiusInput = editTextCelsius.getText().toString();
                if (!celsiusInput.isEmpty()) {
                    double celsius = Double.parseDouble(celsiusInput);
                    double fahrenheit = celsius * 9 / 5 + 32;
                    editTextFahrenheit.setText(String.format("%.2f", fahrenheit));
                } else {
                    Toast.makeText(phuc1.this, "Please enter Celsius value", Toast.LENGTH_SHORT).show();
                }
            }
        });

        btnClear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                editTextFahrenheit.setText("");
                editTextCelsius.setText("");
            }
        });
    }
}

