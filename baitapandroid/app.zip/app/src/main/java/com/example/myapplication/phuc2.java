package com.example.myapplication;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class phuc2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.phuc_b2);

        EditText edtName = findViewById(R.id.edtName);
        EditText edtHeight = findViewById(R.id.edtHeight);
        EditText edtWeight = findViewById(R.id.edtWeight);
        Button btnCalculateBMI = findViewById(R.id.btnCalculateBMI);
        TextView tvBMI = findViewById(R.id.tvBMI);
        TextView tvDiagnosis = findViewById(R.id.tvDiagnosis);

        btnCalculateBMI.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name = edtName.getText().toString().trim();
                String heightStr = edtHeight.getText().toString().trim();
                String weightStr = edtWeight.getText().toString().trim();

                if (heightStr.isEmpty() || weightStr.isEmpty()) {
                    tvDiagnosis.setText("Vui lòng nhập đầy đủ thông tin.");
                    return;
                }

                double height = Double.parseDouble(heightStr);
                double weight = Double.parseDouble(weightStr);

                double bmi = weight / (height * height);
                tvBMI.setText("BMI = " + String.format("%.1f", bmi));

                String diagnosis;
                if (bmi < 18) {
                    diagnosis = "Bạn gầy";
                } else if (bmi >= 18 && bmi <= 24.9) {
                    diagnosis = "Bạn bình thường";
                } else if (bmi >= 25 && bmi <= 29.9) {
                    diagnosis = "Bạn béo phì độ I";
                } else if (bmi >= 30 && bmi <= 34.9) {
                    diagnosis = "Bạn béo phì độ II";
                } else {
                    diagnosis = "Bạn béo phì độ III";
                }

                tvDiagnosis.setText("Chẩn đoán: " + diagnosis);
            }
        });
    }
}
