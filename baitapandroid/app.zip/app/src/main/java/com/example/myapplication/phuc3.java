package com.example.myapplication;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class phuc3 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.phuc_b3);

        EditText edtNumberA = findViewById(R.id.edtNumberA);
        EditText edtNumberB = findViewById(R.id.edtNumberB);
        Button btnAdd = findViewById(R.id.btnAdd);
        Button btnSubtract = findViewById(R.id.btnSubtract);
        Button btnMultiply = findViewById(R.id.btnMultiply);
        Button btnDivide = findViewById(R.id.btnDivide);
        TextView tvResult = findViewById(R.id.tvResult);

        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String strA = edtNumberA.getText().toString().trim();
                String strB = edtNumberB.getText().toString().trim();

                if (strA.isEmpty() || strB.isEmpty()) {
                    Toast.makeText(phuc3.this, "Vui lòng nhập đầy đủ số a và b", Toast.LENGTH_SHORT).show();
                    return;
                }

                double a = Double.parseDouble(strA);
                double b = Double.parseDouble(strB);
                double result = a + b;

                tvResult.setText("Kết quả: " + result);
            }
        });

        btnSubtract.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String strA = edtNumberA.getText().toString().trim();
                String strB = edtNumberB.getText().toString().trim();

                if (strA.isEmpty() || strB.isEmpty()) {
                    Toast.makeText(phuc3.this, "Vui lòng nhập đầy đủ số a và b", Toast.LENGTH_SHORT).show();
                    return;
                }

                double a = Double.parseDouble(strA);
                double b = Double.parseDouble(strB);
                double result = a - b;

                tvResult.setText("Kết quả: " + result);
            }
        });

        btnMultiply.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String strA = edtNumberA.getText().toString().trim();
                String strB = edtNumberB.getText().toString().trim();

                if (strA.isEmpty() || strB.isEmpty()) {
                    Toast.makeText(phuc3.this, "Vui lòng nhập đầy đủ số a và b", Toast.LENGTH_SHORT).show();
                    return;
                }

                double a = Double.parseDouble(strA);
                double b = Double.parseDouble(strB);
                double result = a * b;

                tvResult.setText("Kết quả: " + result);
            }
        });

        btnDivide.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String strA = edtNumberA.getText().toString().trim();
                String strB = edtNumberB.getText().toString().trim();

                if (strA.isEmpty() || strB.isEmpty()) {
                    Toast.makeText(phuc3.this, "Vui lòng nhập đầy đủ số a và b", Toast.LENGTH_SHORT).show();
                    return;
                }

                double a = Double.parseDouble(strA);
                double b = Double.parseDouble(strB);

                if (b == 0) {
                    Toast.makeText(phuc3.this, "Không thể chia cho 0", Toast.LENGTH_SHORT).show();
                    return;
                }

                double result = a / b;
                tvResult.setText("Kết quả: " + result);
            }
        });
    }
}
