package com.example.myapplication;

import android.os.Bundle;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class phuc4 extends AppCompatActivity {

    private EditText edtHoTen;
    private RadioGroup rgEducation;
    private CheckBox cbC, cbJava, cbJavascript;
    private Button btnSave;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.phuc_b4);

        // Initialize Views
        edtHoTen = findViewById(R.id.edtHoTen);
        rgEducation = findViewById(R.id.rgEducation);
        cbC = findViewById(R.id.cbC);
        cbJava = findViewById(R.id.cbJava);
        cbJavascript = findViewById(R.id.cbJavascript);
        btnSave = findViewById(R.id.btnSave);

        // Handle Button Click
        btnSave.setOnClickListener(v -> {
            String hoTen = edtHoTen.getText().toString();
            String educationLevel = ((RadioButton) findViewById(rgEducation.getCheckedRadioButtonId())).getText().toString();
            StringBuilder favoriteLanguages = new StringBuilder();

            if (cbC.isChecked()) favoriteLanguages.append("C ");
            if (cbJava.isChecked()) favoriteLanguages.append("Java ");
            if (cbJavascript.isChecked()) favoriteLanguages.append("Javascript ");

            // Show Data in Toast
            Toast.makeText(this, "Họ tên: " + hoTen +
                    "\nHệ: " + educationLevel +
                    "\nNgôn ngữ yêu thích: " + favoriteLanguages.toString(), Toast.LENGTH_LONG).show();
        });
    }
}

